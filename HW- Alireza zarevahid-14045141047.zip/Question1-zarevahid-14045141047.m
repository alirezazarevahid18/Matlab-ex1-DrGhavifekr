% Q01.m - اولین محاسبه قبض برق خانه
clc; clear;

consumptions = [245, 400];

for i = 1:length(consumptions)
    kWh = consumptions(i);
    if kWh <= 100
        cost = kWh * 1500;
    else
        cost = (100 * 1500) + ((kWh - 100) * 3000);
    end
    fprintf('هزینه قبض برای مصرف %d کیلووات ساعت: %d تومان\n', kWh, cost);
end
