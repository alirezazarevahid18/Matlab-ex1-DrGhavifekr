%% Question 10
% Student ID: 14045141047
disp('Question 10 - Student ID: 14045141047')
% Sorat be masafat
% alef) trapz
t = 0:0.01:5;
v = 3*t.^2 + 2*t;
d1 = trapz(t, v);

% b) int
syms x
d2 = double(int(3*x^2 + 2*x, x, 0, 5));
fprintf('trapz = %.5f\n', d1);
fprintf('int = %.5f\n', d2);

% p) gam 0.5
t2 = 0:0.5:5;
v2 = 3*t2.^2 + 2*t2;
d3 = trapz(t2, v2);
fprintf('Ekhtelaf = %.5f\n', abs(d3 - d2));

% t) cumtrapz
c = cumtrapz(t, v);
k = find(c >= d1/2, 1);
fprintf('Nime masafat dar t = %.2f\n', t(k));
