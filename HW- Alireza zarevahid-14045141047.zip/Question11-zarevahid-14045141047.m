%% Question 11
% Student ID: 14045141047
disp('Question 11 - Student ID: 14045141047')
% Limit
syms t x

% alef)
a = limit((1 - cos(t)) / t^2, t, 0);
disp(a)

% b)
b = limit((2*t + 1) / (t - 3), t, inf);
disp(b)

% p)
l = limit(1/x, x, 0, 'left');
r = limit(1/x, x, 0, 'right');
disp(l)
disp(r)
