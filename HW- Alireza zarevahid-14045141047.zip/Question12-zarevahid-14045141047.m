%% Question 12
% Student ID: 14045141047
disp('Question 12 - Student ID: 14045141047')
% Adad mokhtalet
% alef)
z = (2 + 3i) / (3 - 4i);
fprintf('z = %.2f + %.2fi\n', real(z), imag(z));

% b) impedans
R = 10;
L = 0.1;
C = 2e-4;
f = 50;
w = 2 * pi * f;
Z = R + 1i * (w*L - 1/(w*C));
fprintf('Real = %.3f\n', real(Z));
fprintf('Imag = %.3f\n', imag(Z));

% p) andaze va zaviye
fprintf('abs = %.3f\n', abs(Z));
fprintf('angle = %.3f degree\n', angle(Z) * 180 / pi);
