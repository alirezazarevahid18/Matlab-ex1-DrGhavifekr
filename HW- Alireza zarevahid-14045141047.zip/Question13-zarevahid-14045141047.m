%% Question 13
% Student ID: 14045141047
disp('Question 13 - Student ID: 14045141047')
% Laplace
% alef)
syms s t
Is = 12 / (s * (4 + 0.2*s));

% b)
it = ilaplace(Is, s, t);
disp(it)

% p)
i1 = double(subs(it, t, 0.1));
i2 = double(subs(it, t, 1));
fprintf('i(0.1) = %.4f A\n', i1);
fprintf('i(1) = %.4f A\n', i2);

% t) halat mandegar
iss = limit(it, t, inf);
fprintf('limit = %.4f , V/R = %.4f\n', double(iss), 12/4);
