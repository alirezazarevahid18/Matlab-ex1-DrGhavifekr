%% Question 14
% Student ID: 14045141047
disp('Question 14 - Student ID: 14045141047')
% Halghe ha
% alef) for
for k = 3:2:34
    fprintf('%d ', k);
end
fprintf('\n');

% while
k = 3;
while k <= 34
    fprintf('%d ', k);
    k = k + 2;
end
fprintf('\n');

% b) jam
x = input('x = ');
n = input('n = ');
y = 0;
for k = 1:n
    y = y + (2/x)^k;
end
fprintf('y = %.4f\n', y);

% test x=2 n=10
x = 2;
n = 10;
y = 0;
for k = 1:n
    y = y + (2/x)^k;
end
fprintf('y (test) = %.4f\n', y);

% p) robot
v = 0;
count = 0;
while abs(500 - v) >= 5
    v = v + 0.1 * (500 - v);
    count = count + 1;
end
fprintf('v = %.3f, gam = %d\n', v, count);
