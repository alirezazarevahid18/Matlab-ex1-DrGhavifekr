%% Question 15
% Student ID: 14045141047
disp('Question 15 - Student ID: 14045141047')
% Tabe ha (c2k.m, norm3.m, powerCalc.m bayad dar hamin pooshe bashan)
% alef)
disp(c2k(0))
disp(c2k(25))
disp(c2k(100))

% b)
disp(norm3([3 4]))
disp(norm3([1 2 2]))

% p)
[P, S] = powerCalc(220, 5, 0.9);
fprintf('P = %.2f W\n', P);
fprintf('S = %.2f VA\n', S);
