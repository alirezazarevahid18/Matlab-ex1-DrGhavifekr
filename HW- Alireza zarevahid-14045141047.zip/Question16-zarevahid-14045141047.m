% Q16.m - رسم دو بعدی از توابع تا سیگنال مخابراتی
clc; clear; close all;

% الف) دو تابع y1 و y2
t = 0:0.1:5;
y1 = (sin(t) .* (cos(t).^2)) ./ (t.^2 + 1);
y2 = sqrt(t.^3) .* exp(2);

figure;
plot(t, y1, 'b-', 'LineWidth', 1.5); hold on;
plot(t, y2, 'r--', 'LineWidth', 2.0);
title('نمودار توابع y1 و y2');
xlabel('زمان (t)');
ylabel('دامنه');
legend('y1(t)', 'y2(t)');
grid on;

% ب) سه تابع f و Z و k با subplot
x = -2:0.05:2;
f = (sin(x).^2) + (sinh(x).^2);
Z = (cos(x).^2) + (cosh(x).^2);
k = (x.^2) + (2 * x .* sin(x));

figure;
subplot(3,1,1); plot(x, f, 'm', 'LineWidth', 1.2); title('تابع f(x)'); grid on;
subplot(3,1,2); plot(x, Z, 'g', 'LineWidth', 1.2); title('تابع Z(x)'); grid on;
subplot(3,1,3); plot(x, k, 'c', 'LineWidth', 1.2); title('تابع k(x)'); grid on;

% پ) موج حامل و نمونه برداری گسسته
t_cont = 0:0.0012:2;
s_cont = sin(2 * pi * 3 * t_cont);

t_disc = 0:0.1:2;
s_disc = sin(2 * pi * 3 * t_disc);

figure;
subplot(2,1,1); plot(t_cont, s_cont, 'b', 'LineWidth', 1.2); title('سیگنال پیوسته s(t)'); grid on;
subplot(2,1,2); stem(t_disc, s_disc, 'r', 'LineWidth', 1.2); title('نمونه‌های گسسته (stem)'); grid on;
xlabel('زمان (ثانیه)'); ylabel('دامنه');
