%% Question 17
% Student ID: 14045141047
disp('Question 17 - Student ID: 14045141047')
% Bar va pie
% alef)
d = rand(1,5);
figure(1)
bar(d, 'r')

% b)
share = [22 28 8 33 11];
figure(2)
pie(share)

% p)
ex = [0 0 0 1 0];
names = {'Sarmayesh', 'Abgarmkon', 'Roshanaei', 'Sayer', 'Shaarj'};
figure(3)
pie(share, ex, names)
