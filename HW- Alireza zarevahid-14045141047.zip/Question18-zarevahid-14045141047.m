% Q18.m - ریشه دوم با تکرار (بدون استفاده از sqrt)
clc; clear;

a = input('لطفاً عدد مورد نظر را وارد کنید (a): ');

% بررسی مثبت بودن ورودی
if a <= 0
    error('خطا: عدد وارد شده باید مثبت و بزرگتر از صفر باشد!');
end

x = a; % حدس اولیه
diff_val = inf;
iterations = 0;

while diff_val >= 0.0001
    x_new = (x + a/x) / 2;
    diff_val = abs(x_new - x);
    x = x_new;
    iterations = iterations + 1;
end

fprintf('ریشه دوم محاسبه شده: %.5f\n', x);
fprintf('تعداد تکرارها: %d\n', iterations);

exact_sqrt = sqrt(a);
error_val = abs(x - exact_sqrt);
fprintf('خروجی دستور sqrt: %.5f\n', exact_sqrt);
fprintf('اختلاف با جواب دقیق: %.7f\n', error_val);
