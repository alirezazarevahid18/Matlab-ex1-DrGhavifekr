%% Question 19
% Student ID: 14045141047
disp('Question 19 - Student ID: 14045141047')
% Matris motegharen
% alef)
A = rand(4);
if isequal(A, A')
    disp('A motegharene')
else
    disp('A motegharen nist')
end

% b)
S = (A + A') / 2;
if isequal(S, S')
    disp('S motegharene')
else
    disp('S motegharen nist')
end

% p)
B = [1 2 3; 2 5 6; 3 6 9];
if isequal(B, B')
    disp('B motegharene')
else
    disp('B motegharen nist')
end
