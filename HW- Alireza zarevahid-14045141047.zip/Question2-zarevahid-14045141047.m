%% Question 2
% Student ID: 14045141047
disp('Question 2 - Student ID: 14045141047')
% Panel khorshidi
% alef) data
daily = 4.2;
price = 5000;

% b) daramad
monthIncome = daily * 30 * price;
yearIncome = daily * 365 * price;

% p) chap
fprintf('Income: %.2f Toman\n', monthIncome);
fprintf('Year Income: %.2f Toman\n', yearIncome);
fprintf('Darsad ba %%%% chap mishe: 50%%\n');

% t) who va format
who
format long
disp(10/3)
format short
disp(10/3)
