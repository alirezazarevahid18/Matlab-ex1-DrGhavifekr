%% Question 20
% Student ID: 14045141047
disp('Question 20 - Student ID: 14045141047')
% Moadele daraje 2
% alef)
a = input('a = ');
b = input('b = ');
c = input('c = ');
p = [a b c];
r = roots(p);
disp(r)

% b) resm
if isreal(r)
    x = (min(r) - 1):0.01:(max(r) + 1);
else
    x = -10:0.01:10;
end
y = polyval(p, x);
figure(1)
plot(x, y)
title('Sahmi')
xlabel('x')
ylabel('y')
grid on

% p) rishe ha
if isreal(r)
    hold on
    plot(r, [0 0], 'ro')
end
