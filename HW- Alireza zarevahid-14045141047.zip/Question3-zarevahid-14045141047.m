%% Question 3
% Student ID: 14045141047
disp('Question 3 - Student ID: 14045141047')
% Ghanoon Ohm
% alef) voroodi
V = input('Voltage (V) = ');
R = input('Resistance (Ohm) = ');

% b) mohasebe
I = V / R;
P = V * I;

% p) chap
fprintf('Current = %.4f A\n', I);
fprintf('Power = %.4f W\n', P);

% t) 12 volt va 820 ohm dar file
V = 12;
R = 820;
I = V / R;
P = V * I;
f = fopen('ohm_result.txt', 'w');
fprintf(f, 'Voltage = %d V\n', V);
fprintf(f, 'Resistance = %d Ohm\n', R);
fprintf(f, 'Current = %.4f A\n', I);
fprintf(f, 'Power = %.4f W\n', P);
fclose(f);
disp('Saved in ohm_result.txt')
