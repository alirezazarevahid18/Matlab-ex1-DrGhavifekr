% Q04.m - سنسور دما تحلیل یک بردار داده
clc; clear;

temp = [22.5, 22.8, 23.1, 24.0, 25.2, 26.1, 26.0, 25.4, 24.3, 23.2];

avg_temp = mean(temp);
max_temp = max(temp);
min_temp = min(temp);
std_temp = std(temp);

fprintf('میانگین دما: %.2f\n', avg_temp);
fprintf('بیشینه دما: %.2f\n', max_temp);
fprintf('کمینه دما: %.2f\n', min_temp);
fprintf('انحراف معیار: %.2f\n', std_temp);

% انحراف هر قرائت از میانگین بدون استفاده از حلقه
deviation = temp - avg_temp;
disp('انحراف هر قرائت از میانگین:');
disp(deviation);

% مرتب‌سازی و چاپ سومین قرائت
sorted_temp = sort(temp);
fprintf('سومین قرائت مرتب شده: ');
disp(sorted_temp(3));
