%% Question 5
% Student ID: 14045141047
disp('Question 5 - Student ID: 14045141047')
% Matris random
% alef) matris
A = 10 * rand(4);
disp(A)

% b) max va min va jashoon
big = max(max(A));
small = min(min(A));
[r1, c1] = find(A == big);
[r2, c2] = find(A == small);
fprintf('Max = %.3f, satr %d, sotoon %d\n', big, r1, c1);
fprintf('Min = %.3f, satr %d, sotoon %d\n', small, r2, c2);

% p) jabeja
temp = A(r1, c1);
A(r1, c1) = A(r2, c2);
A(r2, c2) = temp;
disp(A)

% t) miangin sotoon ha
disp(mean(A))
