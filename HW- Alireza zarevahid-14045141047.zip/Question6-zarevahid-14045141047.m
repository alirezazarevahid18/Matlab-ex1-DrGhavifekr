%% Question 6
% Student ID: 14045141047
disp('Question 6 - Student ID: 14045141047')
% Anbar
A = [120 80 45; 200 60 30; 90 140 75];
p = [35000; 80000; 120000];

% alef) zarb matrisi
v = A * p;
for k = 1:3
    fprintf('Shobe %d = %d Toman\n', k, v(k));
end

% b) ba .*
% Transpose p so each price matches its product-type column.
w = A .* p';
disp(v)
disp(w)

% p) tranahade
B = A';
disp(B)

% t) jam ghataat
n = A * ones(3,1);
disp(n)
