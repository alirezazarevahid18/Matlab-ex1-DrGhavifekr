%% Question 7
% Student ID: 14045141047
disp('Question 7 - Student ID: 14045141047')
% Khazen
% alef) voltage
t = [0 1 2 5 10];
v = 12 * (1 - exp(-t/2));
for k = 1:5
    fprintf('t = %d, v = %.3f\n', t(k), v(k));
end

% b) 95 darsad
t95 = -2 * log(0.05);
fprintf('t95 = %.3f s\n', t95);

% p) dasharj
v2 = 12 * exp(-t/2);
fprintf('v(10) = %.5f V\n', v2(5));
