%% Question 8
% Student ID: 14045141047
disp('Question 8 - Student ID: 14045141047')
% Partab
% alef) polyval
p = [-5 40 0];
t = [0 2 4 6];
h = polyval(p, t);
disp(h)

% b) rishe ha
r = roots(p);
disp(r)

% p) conv
c = conv([5 0], [-1 8]);
disp(c)
if isequal(c, p)
    disp('Barabare')
else
    disp('Barabar nist')
end

% t) bishtarin ertefa
a = p(1);
b = p(2);
tm = -b / (2*a);
hm = polyval(p, tm);
fprintf('t = %.2f, h = %.2f\n', tm, hm);
