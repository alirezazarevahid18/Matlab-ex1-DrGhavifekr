%% Question 9
% Student ID: 14045141047
disp('Question 9 - Student ID: 14045141047')
% Sorat va shetab
% alef) data
t = 0:0.5:20;
s = 60 * (1 - exp(-t/5));

% b) diff va gradient
v1 = diff(s) ./ diff(t);
v2 = gradient(s, 0.5);
fprintf('length t = %d\n', length(t));
fprintf('length diff = %d\n', length(v1));
fprintf('length gradient = %d\n', length(v2));

% p) nemadin
syms T
S = 60 * (1 - exp(-T/5));
V = diff(S, T);
v5 = double(subs(V, T, 5));
fprintf('v(5) nemadin = %.4f\n', v5);

% t) max va sanie 10
fprintf('Max speed = %.4f\n', max(v2));
a2 = gradient(v2, 0.5);
k = find(t == 10);
fprintf('v(10) = %.4f\n', v2(k));
fprintf('a(10) = %.4f\n', a2(k));
