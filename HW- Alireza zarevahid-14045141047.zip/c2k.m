function K = c2k(C)
% Student ID: 14045141047
K = C + 273.15;
end
