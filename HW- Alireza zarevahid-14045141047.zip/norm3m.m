function n = norm3m(v)
% Student ID: 14045141047
% Q15 - Part B: Calculate 3-norm of a vector
sum_cubes = 0;
for i = 1:length(v)
    sum_cubes = sum_cubes + abs(v(i))^3;
end
n = sum_cubes^(1/3);
end
