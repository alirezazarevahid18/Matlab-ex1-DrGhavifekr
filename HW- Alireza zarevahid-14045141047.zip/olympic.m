clc;
clear;
close all;

figure;
hold on;

% Blue circle
[x, y] = getCircle([0, 0], 1);
plot(x, y, 'b', 'LineWidth', 2);

% Black circle
[x, y] = getCircle([2.1, 0], 1);
plot(x, y, 'k', 'LineWidth', 2);

% Red circle
[x, y] = getCircle([4.2, 0], 1);
plot(x, y, 'r', 'LineWidth', 2);

% Yellow circle
[x, y] = getCircle([1.1, -1], 1);
plot(x, y, 'y', 'LineWidth', 2);

% Green circle
[x, y] = getCircle([3.2, -1], 1);
plot(x, y, 'g', 'LineWidth', 2);

axis equal;
axis([-1.5 5.5 -2.5 1.5]);

title('Olympic Flag');
grid on;
