function [P, S] = powerCalc(V, I, pf)
% Student ID: 14045141047
S = V * I;
P = V * I * pf;
end
